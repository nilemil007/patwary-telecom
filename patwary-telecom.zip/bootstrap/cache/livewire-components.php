<?php return array (
  'auth.login.show-hide-password' => 'App\\Http\\Livewire\\Auth\\Login\\ShowHidePassword',
  'bp.change-password' => 'App\\Http\\Livewire\\Bp\\ChangePassword',
  'bp.profile.image' => 'App\\Http\\Livewire\\Bp\\Profile\\Image',
  'rso.change-password' => 'App\\Http\\Livewire\\Rso\\ChangePassword',
  'rso.profile.picture' => 'App\\Http\\Livewire\\Rso\\Profile\\Picture',
);